import { NextResponse } from "next/server";
import {
  emptySpecs,
  extractProductSpecs,
  mergeSources,
  normalizeProductInput,
  type SearchOptions
} from "@/lib/spec-extractor";
import { searchWithProviders } from "@/lib/search-providers";

export const runtime = "nodejs";
export const maxDuration = 60;

type SearchRequest = {
  products?: string[] | string;
  useExa?: boolean;
  useTavily?: boolean;
  maxResults?: number;
  country?: SearchOptions["country"];
};

const MAX_PRODUCTS = Number(process.env.SCRAPER_MAX_PRODUCTS || 8);
const MAX_AI_RESULTS = Number(process.env.SCRAPER_MAX_AI_RESULTS || 8);

export async function POST(request: Request) {
  let payload: SearchRequest;

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: "JSON invalido." }, { status: 400 });
  }

  const products = normalizeProductInput(payload.products).slice(0, MAX_PRODUCTS);

  if (!products.length) {
    return NextResponse.json({ error: "Informe pelo menos um produto." }, { status: 400 });
  }

  const options: SearchOptions = {
    useExa: payload.useExa !== false,
    useTavily: payload.useTavily !== false,
    maxResults: Math.max(1, Math.min(Number(payload.maxResults || MAX_AI_RESULTS), 12)),
    country: payload.country || "brazil"
  };

  if (!options.useExa && !options.useTavily) {
    return NextResponse.json({ error: "Selecione Exa, Tavily ou ambos." }, { status: 400 });
  }

  const startedAt = Date.now();

  const results = await Promise.all(
    products.map(async (product) => {
      try {
        const providerResults = await searchWithProviders(product, options);
        const sources = mergeSources(providerResults.sources);
        const specs = extractProductSpecs(product, sources);
        specs.notes.push(...providerResults.notes);
        return specs;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Erro inesperado.";
        return {
          ...emptySpecs(product, [message]),
          status: "error" as const
        };
      }
    })
  );

  return NextResponse.json({
    results,
    meta: {
      products: products.length,
      elapsedMs: Date.now() - startedAt,
      providers: {
        exa: options.useExa,
        tavily: options.useTavily
      }
    }
  });
}
