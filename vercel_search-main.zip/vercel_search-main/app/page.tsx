"use client";

import { useMemo, useState } from "react";

type Provider = "exa" | "tavily" | "manual";

type SpecField = {
  value: string | null;
  sourceUrl?: string;
  sourceTitle?: string;
  provider?: Provider;
  evidence?: string;
};

type ProductSpecs = {
  product: string;
  status: "found" | "partial" | "not_found" | "error";
  confidence: number;
  fields: {
    powerW: SpecField;
    voltageV: SpecField;
    consumptionKwh: SpecField;
    btu: SpecField;
    phase: SpecField;
    currentA: SpecField;
    gasConsumption: SpecField;
  };
  sources: Array<{
    provider: Provider;
    title: string;
    url: string;
    content: string;
    score?: number;
  }>;
  notes: string[];
};

type ApiResponse = {
  results: ProductSpecs[];
  meta: {
    products: number;
    elapsedMs: number;
    providers: {
      exa: boolean;
      tavily: boolean;
    };
  };
};

const FIELD_LABELS: Array<[keyof ProductSpecs["fields"], string]> = [
  ["powerW", "Potencia"],
  ["voltageV", "Voltagem"],
  ["consumptionKwh", "Consumo"],
  ["btu", "BTU"],
  ["phase", "Fase"],
  ["currentA", "Corrente"],
  ["gasConsumption", "Gas"]
];

const EXAMPLE_PRODUCTS = [
  "EXPOSITOR APOLO FRIO MODELO 2404",
  "Counter-Depth French Door Refrigerator with Internal Water Dispenser",
  "Forno combinado Rational iCombi Pro 10-1/1"
].join("\n");

export default function Home() {
  const [products, setProducts] = useState(EXAMPLE_PRODUCTS);
  const [useExa, setUseExa] = useState(true);
  const [useTavily, setUseTavily] = useState(true);
  const [country, setCountry] = useState("brazil");
  const [maxResults, setMaxResults] = useState(8);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<ApiResponse | null>(null);

  const productCount = useMemo(
    () => products.split(/\r?\n|;/).map((item) => item.trim()).filter(Boolean).length,
    [products]
  );

  async function runSearch() {
    setLoading(true);
    setError(null);
    setData(null);

    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          products,
          useExa,
          useTavily,
          country,
          maxResults
        })
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error || "Falha ao buscar especificacoes.");
      }

      setData(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado.");
    } finally {
      setLoading(false);
    }
  }

  function exportCsv() {
    if (!data?.results.length) return;

    const header = [
      "produto",
      "status",
      "confianca",
      "potencia_w",
      "voltagem_v",
      "consumo_kwh",
      "btu",
      "fase",
      "corrente_a",
      "consumo_gas",
      "fonte_potencia",
      "fonte_voltagem",
      "fonte_consumo"
    ];

    const rows = data.results.map((result) => [
      result.product,
      result.status,
      String(result.confidence),
      result.fields.powerW.value || "",
      result.fields.voltageV.value || "",
      result.fields.consumptionKwh.value || "",
      result.fields.btu.value || "",
      result.fields.phase.value || "",
      result.fields.currentA.value || "",
      result.fields.gasConsumption.value || "",
      result.fields.powerW.sourceUrl || "",
      result.fields.voltageV.sourceUrl || "",
      result.fields.consumptionKwh.sourceUrl || ""
    ]);

    const csv = [header, ...rows]
      .map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "especificacoes.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="shell">
      <section className="workspace">
        <aside className="control-panel">
          <div className="brand">
            <span className="brand-mark">BS</span>
            <div>
              <h1>Busca de Specs</h1>
              <p>Exa + Tavily para fichas tecnicas</p>
            </div>
          </div>

          <label className="field">
            <span>Produtos</span>
            <textarea
              value={products}
              onChange={(event) => setProducts(event.target.value)}
              rows={10}
              spellCheck={false}
            />
          </label>

          <div className="split">
            <label className="check">
              <input type="checkbox" checked={useExa} onChange={(event) => setUseExa(event.target.checked)} />
              <span>Exa</span>
            </label>
            <label className="check">
              <input
                type="checkbox"
                checked={useTavily}
                onChange={(event) => setUseTavily(event.target.checked)}
              />
              <span>Tavily</span>
            </label>
          </div>

          <label className="field">
            <span>País de busca</span>
            <select value={country} onChange={(event) => setCountry(event.target.value)}>
              <option value="brazil">Brasil</option>
              <option value="united states">Estados Unidos</option>
              <option value="mexico">Mexico</option>
              <option value="global">Global</option>
            </select>
          </label>

          <label className="field">
            <span>Resultados por fonte: {maxResults}</span>
            <input
              type="range"
              min="3"
              max="12"
              value={maxResults}
              onChange={(event) => setMaxResults(Number(event.target.value))}
            />
          </label>

          <button className="primary" onClick={runSearch} disabled={loading || productCount === 0}>
            {loading ? "Buscando..." : `Buscar ${productCount} produto${productCount === 1 ? "" : "s"}`}
          </button>

          <button className="secondary" onClick={exportCsv} disabled={!data?.results.length}>
            Exportar CSV
          </button>

          {error ? <p className="error">{error}</p> : null}
        </aside>

        <section className="results-panel">
          <div className="toolbar">
            <div>
              <p className="eyebrow">Scraper Vercel</p>
              <h2>Resultados normalizados</h2>
            </div>
            {data ? (
              <div className="run-meta">
                <span>{data.meta.products} produtos</span>
                <span>{(data.meta.elapsedMs / 1000).toFixed(1)}s</span>
              </div>
            ) : null}
          </div>

          {!data && !loading ? (
            <div className="empty-state">
              <h3>Pronto para pesquisar</h3>
              <p>
                Cole uma lista de equipamentos, ative Exa e Tavily, e a API retorna potencia, voltagem,
                consumo, BTU, corrente, fase e fontes usadas.
              </p>
            </div>
          ) : null}

          {loading ? (
            <div className="loading-state">
              <div className="spinner" />
              <p>Consultando provedores e extraindo especificacoes...</p>
            </div>
          ) : null}

          <div className="result-list">
            {data?.results.map((result) => (
              <article className="result-card" key={result.product}>
                <div className="result-head">
                  <div>
                    <p className={`status ${result.status}`}>{statusLabel(result.status)}</p>
                    <h3>{result.product}</h3>
                  </div>
                  <div className="confidence">
                    <strong>{result.confidence}%</strong>
                    <span>confianca</span>
                  </div>
                </div>

                <div className="spec-grid">
                  {FIELD_LABELS.map(([key, label]) => {
                    const field = result.fields[key];
                    return (
                      <div className="spec-cell" key={key}>
                        <span>{label}</span>
                        <strong>{field.value || "Nao encontrado"}</strong>
                        {field.sourceUrl ? (
                          <a href={field.sourceUrl} target="_blank" rel="noreferrer">
                            {field.provider || "fonte"}
                          </a>
                        ) : null}
                      </div>
                    );
                  })}
                </div>

                <details>
                  <summary>Fontes e evidencias</summary>
                  <div className="source-list">
                    {Object.entries(result.fields)
                      .filter(([, field]) => field.value)
                      .map(([key, field]) => (
                        <div className="source-line" key={key}>
                          <strong>{field.value}</strong>
                          <span>{field.evidence}</span>
                          {field.sourceUrl ? (
                            <a href={field.sourceUrl} target="_blank" rel="noreferrer">
                              {field.sourceTitle || field.sourceUrl}
                            </a>
                          ) : null}
                        </div>
                      ))}
                  </div>

                  {result.notes.length ? (
                    <ul className="notes">
                      {result.notes.map((note) => (
                        <li key={note}>{note}</li>
                      ))}
                    </ul>
                  ) : null}
                </details>
              </article>
            ))}
          </div>
        </section>
      </section>
    </main>
  );
}

function statusLabel(status: ProductSpecs["status"]) {
  if (status === "found") return "Completo";
  if (status === "partial") return "Parcial";
  if (status === "error") return "Erro";
  return "Sem match";
}
