export type Provider = "exa" | "tavily" | "manual";

export type SourceHit = {
  provider: Provider;
  title: string;
  url: string;
  content: string;
  score?: number;
};

export type SpecField = {
  value: string | null;
  sourceUrl?: string;
  sourceTitle?: string;
  provider?: Provider;
  evidence?: string;
};

export type ProductSpecs = {
  product: string;
  status: "found" | "partial" | "not_found" | "error";
  confidence: number;
  fields: {
    powerW: SpecField;
    voltageV: SpecField;
    consumptionKwh: SpecField;
    btu: SpecField;
    phase: SpecField;
    currentA: SpecField;
    gasConsumption: SpecField;
  };
  sources: SourceHit[];
  notes: string[];
};

export type SearchOptions = {
  useExa: boolean;
  useTavily: boolean;
  maxResults: number;
  country: "brazil" | "united states" | "mexico" | "global";
};

type ExtractedValue = {
  key: keyof ProductSpecs["fields"];
  value: string;
  evidence: string;
};

const DEFAULT_FIELD: SpecField = { value: null };

const EQUIPMENT_TERMS = [
  "ficha tecnica",
  "especificacoes",
  "especificacao",
  "manual",
  "datasheet",
  "potencia",
  "voltagem",
  "tensao",
  "consumo",
  "btu",
  "amperes"
];

const HP_TO_WATTS: Record<string, number> = {
  "1/8": 93,
  "1/6": 124,
  "1/5": 149,
  "1/4": 186,
  "1/3": 249,
  "1/2": 373,
  "3/4": 559,
  "1": 746,
  "1.5": 1119,
  "2": 1492,
  "3": 2238,
  "5": 3730
};

export function normalizeProductInput(input: unknown): string[] {
  if (Array.isArray(input)) {
    return input.map(String).map((item) => item.trim()).filter(Boolean);
  }

  if (typeof input === "string") {
    return input
      .split(/\r?\n|;/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

export function buildQuery(product: string): string {
  const simplified = product
    .replace(/\b(comp(?:rimento)?|larg(?:ura)?|alt(?:ura)?|prof(?:undidade)?)\s*[:\-]?\s*\d+[.,]?\d*\s*(m|cm|mm)?\b/gi, "")
    .replace(/\b\d+\s*x\s*\d+(?:\s*x\s*\d+)?\b/gi, "")
    .replace(/\s{2,}/g, " ")
    .trim();

  const target = simplified.length > 5 ? simplified : product;
  return `${target} ficha tecnica especificacoes potencia watts voltagem consumo`;
}

export function emptySpecs(product: string, notes: string[] = []): ProductSpecs {
  return {
    product,
    status: "not_found",
    confidence: 0,
    fields: {
      powerW: { ...DEFAULT_FIELD },
      voltageV: { ...DEFAULT_FIELD },
      consumptionKwh: { ...DEFAULT_FIELD },
      btu: { ...DEFAULT_FIELD },
      phase: { ...DEFAULT_FIELD },
      currentA: { ...DEFAULT_FIELD },
      gasConsumption: { ...DEFAULT_FIELD }
    },
    sources: [],
    notes
  };
}

export function mergeSources(...groups: SourceHit[][]): SourceHit[] {
  const seen = new Set<string>();
  const merged: SourceHit[] = [];

  for (const group of groups) {
    for (const source of group) {
      const key = source.url.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      merged.push({
        ...source,
        content: sanitizeText(source.content).slice(0, 12000)
      });
    }
  }

  return merged;
}

export function extractProductSpecs(product: string, sources: SourceHit[]): ProductSpecs {
  const result = emptySpecs(product);
  const ranked = sources
    .map((source) => ({ source, relevance: scoreSource(product, source) }))
    .filter((item) => item.relevance > 0)
    .sort((a, b) => b.relevance - a.relevance);

  for (const { source } of ranked) {
    const extracted = extractValues(source.content);

    for (const item of extracted) {
      const current = result.fields[item.key];
      if (!current.value) {
        result.fields[item.key] = {
          value: item.value,
          sourceUrl: source.url,
          sourceTitle: source.title || source.url,
          provider: source.provider,
          evidence: item.evidence
        };
      }
    }
  }

  const foundCount = Object.values(result.fields).filter((field) => field.value).length;
  result.sources = ranked.slice(0, 10).map((item) => item.source);
  result.confidence = calculateConfidence(foundCount, ranked.length, result.fields);
  result.status = foundCount >= 3 ? "found" : foundCount > 0 ? "partial" : "not_found";

  if (!sources.length) {
    result.notes.push("Nenhuma fonte retornada por Exa ou Tavily. Verifique as chaves de API.");
  } else if (!ranked.length) {
    result.notes.push("As fontes retornadas tiveram baixa relevancia para o produto informado.");
  }

  if (!result.fields.powerW.value && !result.fields.voltageV.value) {
    result.notes.push("Nao encontrei potencia ou voltagem com confianca suficiente nos snippets.");
  }

  return result;
}

function calculateConfidence(
  foundCount: number,
  sourceCount: number,
  fields: ProductSpecs["fields"]
): number {
  let score = foundCount * 12;
  if (fields.powerW.value) score += 12;
  if (fields.voltageV.value) score += 12;
  if (fields.consumptionKwh.value || fields.currentA.value || fields.btu.value) score += 8;
  score += Math.min(sourceCount, 6) * 3;
  return Math.min(96, Math.max(0, score));
}

function scoreSource(product: string, source: SourceHit): number {
  const text = sanitizeText(`${source.title} ${source.url} ${source.content}`).toLowerCase();
  const productWords = product
    .toLowerCase()
    .split(/\W+/)
    .filter((word) => word.length > 2);

  let score = 0;
  for (const word of productWords) {
    if (text.includes(word)) score += 1;
  }

  for (const term of EQUIPMENT_TERMS) {
    if (text.includes(term)) score += 2;
  }

  if (/\b(w|kw|watts|volts|v|kwh|btu|ampere|amperes|a)\b/i.test(text)) {
    score += 3;
  }

  return score;
}

function extractValues(input: string): ExtractedValue[] {
  const text = sanitizeText(input);
  const values: ExtractedValue[] = [];

  pushMatch(values, "powerW", findPower(text));
  pushMatch(values, "voltageV", findVoltage(text));
  pushMatch(values, "consumptionKwh", findConsumption(text));
  pushMatch(values, "btu", findBtu(text));
  pushMatch(values, "phase", findPhase(text));
  pushMatch(values, "currentA", findCurrent(text));
  pushMatch(values, "gasConsumption", findGasConsumption(text));

  return values;
}

function pushMatch(
  values: ExtractedValue[],
  key: keyof ProductSpecs["fields"],
  found: { value: string; evidence: string } | null
) {
  if (found) {
    values.push({ key, value: found.value, evidence: found.evidence });
  }
}

function findPower(text: string): { value: string; evidence: string } | null {
  const patterns = [
    /\b(?:pot[eê]ncia|power|rated power|potencia eletrica|entrada nominal|input power)\b[^.;\n]{0,90}?(\d+(?:[.,]\d+)?)\s*(kw|w|watts?|hp|cv)\b/i,
    /\b(\d+(?:[.,]\d+)?)\s*(kw|w|watts?|hp|cv)\b[^.;\n]{0,50}\b(?:pot[eê]ncia|power|compressor|motor)\b/i
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (!match) continue;
    const normalized = normalizePower(match[1], match[2]);
    if (normalized) return { value: normalized, evidence: clipEvidence(match[0]) };
  }

  return null;
}

function findVoltage(text: string): { value: string; evidence: string } | null {
  const patterns = [
    /\b(?:voltagem|tens[aã]o|voltage|aliment[aã]o|tension)\b[^.;\n]{0,90}?((?:110|115|120|127|208|220|230|240|254|277|380|400|440|460|480)(?:\s*[\/-]\s*(?:110|115|120|127|208|220|230|240|254|277|380|400|440|460|480))?\s*v?)\b/i,
    /\b((?:110|115|120|127|208|220|230|240|254|277|380|400|440|460|480)(?:\s*[\/-]\s*(?:110|115|120|127|208|220|230|240|254|277|380|400|440|460|480))?\s*v)\b/i
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      return {
        value: match[1].replace(/\s+/g, "").toUpperCase().replace(/V?$/, " V"),
        evidence: clipEvidence(match[0])
      };
    }
  }

  return null;
}

function findConsumption(text: string): { value: string; evidence: string } | null {
  const pattern = /\b(?:consumo|energy consumption|consumption)\b[^.;\n]{0,100}?(\d+(?:[.,]\d+)?)\s*(kwh(?:\/(?:m[eê]s|mes|ano|year|dia|day|h|hora))?|kw\/h)\b/i;
  const match = text.match(pattern);
  if (!match) return null;
  return {
    value: `${match[1].replace(",", ".")} ${match[2].replace("mes", "mês")}`,
    evidence: clipEvidence(match[0])
  };
}

function findBtu(text: string): { value: string; evidence: string } | null {
  const match = text.match(/\b(\d{4,6})\s*(btu\/h|btus?|btu)\b/i);
  if (!match) return null;
  return { value: `${Number(match[1]).toLocaleString("pt-BR")} BTU`, evidence: clipEvidence(match[0]) };
}

function findPhase(text: string): { value: string; evidence: string } | null {
  const match = text.match(/\b(monof[aá]sico|bif[aá]sico|trif[aá]sico|single phase|three phase|1\s*ph|3\s*ph)\b/i);
  if (!match) return null;

  const raw = match[1].toLowerCase();
  let value = match[1];
  if (/mono|single|1/.test(raw)) value = "Monofasico";
  if (/bi/.test(raw)) value = "Bifasico";
  if (/tri|three|3/.test(raw)) value = "Trifasico";

  return { value, evidence: clipEvidence(match[0]) };
}

function findCurrent(text: string): { value: string; evidence: string } | null {
  const match = text.match(/\b(?:corrente|amperagem|amperes|current|rated current)\b[^.;\n]{0,90}?(\d+(?:[.,]\d+)?)\s*a\b/i);
  if (!match) return null;
  return { value: `${match[1].replace(",", ".")} A`, evidence: clipEvidence(match[0]) };
}

function findGasConsumption(text: string): { value: string; evidence: string } | null {
  const match = text.match(/\b(?:consumo de g[aá]s|gas consumption|consumo glp|glp)\b[^.;\n]{0,100}?(\d+(?:[.,]\d+)?)\s*(kg\/h|g\/h|m3\/h|m³\/h)\b/i);
  if (!match) return null;
  return { value: `${match[1].replace(",", ".")} ${match[2]}`, evidence: clipEvidence(match[0]) };
}

function normalizePower(rawValue: string, rawUnit: string): string | null {
  const value = Number(rawValue.replace(",", "."));
  if (!Number.isFinite(value) || value <= 0) return null;

  const unit = rawUnit.toLowerCase();
  if (unit === "kw") return `${Math.round(value * 1000)} W`;
  if (unit === "w" || unit.startsWith("watt")) return `${Math.round(value)} W`;
  if (unit === "hp" || unit === "cv") {
    const lookup = HP_TO_WATTS[String(value)] ?? Math.round(value * 746);
    return `${lookup} W (aprox. ${rawValue} ${rawUnit.toUpperCase()})`;
  }

  return null;
}

function sanitizeText(input: string): string {
  return input
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function clipEvidence(value: string): string {
  return sanitizeText(value).slice(0, 220);
}
