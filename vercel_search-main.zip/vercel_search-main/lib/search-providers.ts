import { buildQuery, type SearchOptions, type SourceHit } from "./spec-extractor";

type ProviderResult = {
  sources: SourceHit[];
  notes: string[];
};

type TavilyResult = {
  title?: string;
  url?: string;
  content?: string;
  raw_content?: string;
  score?: number;
};

type ExaResult = {
  title?: string;
  url?: string;
  text?: string;
  highlights?: string[];
  summary?: string;
  score?: number;
};

export async function searchWithProviders(
  product: string,
  options: SearchOptions
): Promise<ProviderResult> {
  const tasks: Promise<ProviderResult>[] = [];

  if (options.useExa) tasks.push(searchExa(product, options));
  if (options.useTavily) tasks.push(searchTavily(product, options));

  const settled = await Promise.allSettled(tasks);
  const sources: SourceHit[] = [];
  const notes: string[] = [];

  for (const item of settled) {
    if (item.status === "fulfilled") {
      sources.push(...item.value.sources);
      notes.push(...item.value.notes);
    } else {
      notes.push(item.reason instanceof Error ? item.reason.message : "Falha em um provedor de busca.");
    }
  }

  return { sources, notes };
}

async function searchExa(product: string, options: SearchOptions): Promise<ProviderResult> {
  const key = process.env.EXA_API_KEY;
  if (!key) {
    return { sources: [], notes: ["EXA_API_KEY nao configurada. Exa foi ignorado."] };
  }

  const response = await fetchWithTimeout("https://api.exa.ai/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key
    },
    body: JSON.stringify({
      query: buildQuery(product),
      type: "auto",
      numResults: options.maxResults,
      userLocation: countryCode(options.country),
      contents: {
        text: true,
        highlights: true,
        summary: true
      }
    })
  });

  if (!response.ok) {
    return { sources: [], notes: [`Exa retornou ${response.status}.`] };
  }

  const data = await response.json();
  const results = Array.isArray(data.results) ? (data.results as ExaResult[]) : [];

  return {
    sources: results
      .filter((item) => item.url)
      .map((item) => ({
        provider: "exa" as const,
        title: item.title || item.url || "Exa result",
        url: item.url || "",
        content: [item.summary, item.text, ...(item.highlights || [])].filter(Boolean).join(" "),
        score: item.score
      })),
    notes: []
  };
}

async function searchTavily(product: string, options: SearchOptions): Promise<ProviderResult> {
  const key = process.env.TAVILY_API_KEY;
  if (!key) {
    return { sources: [], notes: ["TAVILY_API_KEY nao configurada. Tavily foi ignorado."] };
  }

  const response = await fetchWithTimeout("https://api.tavily.com/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`
    },
    body: JSON.stringify({
      query: buildQuery(product),
      search_depth: "advanced",
      max_results: options.maxResults,
      chunks_per_source: 3,
      include_answer: false,
      include_raw_content: "text",
      include_favicon: true,
      country: options.country === "global" ? undefined : options.country,
      exclude_domains: ["youtube.com", "facebook.com", "instagram.com", "tiktok.com"]
    })
  });

  if (!response.ok) {
    return { sources: [], notes: [`Tavily retornou ${response.status}.`] };
  }

  const data = await response.json();
  const results = Array.isArray(data.results) ? (data.results as TavilyResult[]) : [];

  return {
    sources: results
      .filter((item) => item.url)
      .map((item) => ({
        provider: "tavily" as const,
        title: item.title || item.url || "Tavily result",
        url: item.url || "",
        content: [item.content, item.raw_content].filter(Boolean).join(" "),
        score: item.score
      })),
    notes: []
  };
}

function countryCode(country: SearchOptions["country"]): string | undefined {
  if (country === "brazil") return "BR";
  if (country === "united states") return "US";
  if (country === "mexico") return "MX";
  return undefined;
}

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs = 25000): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}
